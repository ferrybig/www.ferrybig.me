
import { createElement as e } from 'react';
import ReactDom from 'react-dom';


export default function App() {
    return e('h1', { className: 'my-class'}, [
        "Hello world"
    ]);
}

