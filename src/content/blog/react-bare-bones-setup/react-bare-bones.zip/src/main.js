
import { createElement as e } from 'react';
import ReactDOM from 'react-dom';


import App from './App.js';

const domContainer = document.createElement('div');
document.body.appendChild(domContainer);
ReactDOM.render(e(App), domContainer);

